import pyodbc
def create_connection():
    connection = pyodbc.connect(r'DRIVER={SQL Server};SERVER=DESKTOP-4SKDIVG\SQLEXPRESS;DATABASE=Drone')

    return connection